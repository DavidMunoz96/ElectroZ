
// Script para futuras funciones
console.log("ElectroZ cargado correctamente.");
